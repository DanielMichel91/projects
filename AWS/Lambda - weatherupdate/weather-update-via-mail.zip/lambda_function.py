import requests
import boto3
import json

sns = boto3.client('sns')

def lambda_handler(event, context):
    url = 'https://geocoding-api.open-meteo.com/v1/search'
    response = requests.get(url, params={'name': 'Berlin'})
    response_json = response.json()
    lat = response_json['results'][0]['latitude']
    lng = response_json['results'][0]['longitude']
    url_for_lat_and_lng = 'https://api.open-meteo.com/v1/forecast?daily=temperature_2m_max,temperature_2m_min&timezone=Europe%2FBerlin'
    response_lat_lng = requests.get(url_for_lat_and_lng, params={'latitude': lat, 'longitude': lng})
    weather = response_lat_lng.json()
    weather_info = {
        'min_temp' : weather['daily']['temperature_2m_min'],
        'max_temp' : weather['daily']['temperature_2m_max']
    }
    min_temp = weather_info['min_temp'][0]
    sns.publish(
        TopicArn='arn:aws:sns:eu-central-1:606610296747:weather-email',
        Subject='weather update',
        Message=str(min_temp),)